function main;
% main;
% 
% Initializes matlab paths to subfolders
% Timothee Cour, Stella Yu, Jianbo Shi, 2004.
addpath(genpath(pwd));